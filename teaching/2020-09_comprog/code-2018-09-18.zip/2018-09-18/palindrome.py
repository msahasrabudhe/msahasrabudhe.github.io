# Given a string, determine if it is a palindrome, that is, if it reads the same 
#    left-to-right and right-to-left. 

# Take a string as input. 
string = input('Input a string: ')

# Find the size of the string. 
size = len(string)

# Create a string to write string right-to-left. 
reverse = ''

# Populate the reversed string. 
for i in range(size):
    reverse = reverse + string[size - i - 1]

# Compare the two strings. 
if reverse == string:
    print('Yes, a palindrome.')
else:
    print('Not a palindrome.')
