# Introduction to Python functions. 
# 

# <output>   <---   <function> ( <inputs> )

'''
add2: Takes two numbers, and returns their sum. 
'''
def add2(x, y):
    s = x + y
    return s

'''
swap: Takes two numbers, and swaps their values. 
'''
def swap(x, y):
    return y, x


'''
min: Takes a list and returns the minimum element in it, as 
     well as the location of the minimum. 
'''
def minimum(lst):
    size = len(lst)
    idx  = 0
    for x in range(1, size):
        if lst[idx] > lst[x]:
            idx = x
    return lst[idx], idx


'''
selection_sort: Takes a list and returns the sorted list.
'''
def selection_sort(lst):
    size = len(lst)
    for x in range(size):
        m, idx = minimum(lst[x:])
        lst[x], lst[idx+x] = swap(lst[x], lst[idx+x])
    return lst

lst        = [5, -2, -8, 10, 7, 16, 13, 12, 3]
print('Original list is ', lst)
sorted_lst = selection_sort(lst)
print('Sorted list is ', sorted_lst)


