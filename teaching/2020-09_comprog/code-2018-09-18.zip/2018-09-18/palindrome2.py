# Given a string, determine if it is a palindrome, that is, if it reads the same 
#    left-to-right and right-to-left. 

# Take a string as input. 
string = input('Input a string: ')

# Find the size of the string. 
size = len(string)

# Start comparing from left and right. 
x = 0

for i in range(size//2):
    if string[i] == string[size - i - 1]:
        x = x + 1

if x == size//2:
    print('Yes, a palindrome.')
else:
    print('Not a palindrome.')

