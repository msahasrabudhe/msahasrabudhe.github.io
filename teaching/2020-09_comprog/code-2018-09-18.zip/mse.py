# PROBLEM: Given two arrays, compute the MSE
#  between them. 

# Ask for size of the arrays. 
size_of_arrays = int(input('Input size: '))

# Initialise the arrays. 
u = []
t = []

# Populate arrays. 
for i in range(size_of_arrays):
    temp1 = int(input('%d-th element of 1st array: ' %(i)))
    temp2 = int(input('%d-th element of 2nd array: ' %(i)))
    u.append(temp1)
    t.append(temp2)

# Initialise mse to zero.
mse = 0

# Compute mse. 
for i in range(size_of_arrays):
    mse = mse + (u[i] - t[i])**2

# Divide by size of the arrays. 
mse = 1.0*mse/size_of_arrays

# Print it
print(mse)
