# PROBLEM: Ask the user for the size of a list.
# Then ask the user for that many numbers which will
# form a list. 
# Then, print the list in the reverse order. 

# Ask the user for size of the list. 
size_of_list = int(input('Input size of the list: '))

# Create an empty list. 
array = []

# Ask for size_of_list numbers. 
for i in range(size_of_list):
    # Ask for the i-th number.
    temp = int(input('Input %d-th number: ' %(i)))

    # Append it to array.
    array.append(temp)

# Print array in the reverse order. 
for i in range(size_of_list):
    print(array[size_of_list-i-1])

