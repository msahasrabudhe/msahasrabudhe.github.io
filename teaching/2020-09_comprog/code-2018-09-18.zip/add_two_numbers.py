# PROBLEM: Take two numbers as input, and print their sum. 

# Takes an input, stores the value in the variable x. 
x = int(input('Input x: '))  

# Takes an input, stores the value in the variable y.
y = int(input('Input y: '))  

# Add the variables x and y. 
z = x + y

# Print the result.
print(z)
