# PROBLEM: Given a number, print its parity.

# Ask for a number, and store it in the variable x.
x = int(input('Input x: '))

# Compute the remainder when x is divided by two.
remainder = x % 2

# If remainder equals 0, the number is even.
if remainder == 0:
    print('Even.')
else:
    print('Odd.')

print('Finish.')
