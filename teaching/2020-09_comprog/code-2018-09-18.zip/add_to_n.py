# PROBLEM: Given a positive integer N, compute
#   the sum of all numbers from zero to N.

# Read N. 
N = int(input('Input N: '))

# Initialise sum_so_far to zero. 
sum_so_far = 0

# Start iterating over numbers from zero to N. 
for i in range(N+1):
    sum_so_far = sum_so_far + i

# Print the sum. 
print(sum_so_far)
